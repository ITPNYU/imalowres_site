<div class="divider">
  <svg version="1.1" id="Laag_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
viewBox="0 0 90.9 23" style="enable-background:new 0 0 90.9 23;" xml:space="preserve">
  <style type="text/css">
    .st0-x{fill:#FBFAE2;}
    .st1-x{fill:#F3B545;}
    .st2-x{fill:#E83F41;}
  </style>
  <rect x="77.1" y="7.4" class="st0-x" width="13.9" height="8.2"/>
  <rect x="41" y="7.4" class="st0-x" width="18.7" height="8.2"/>
  <rect x="32.8" y="0" class="st0-x" width="8.2" height="23"/>
  <rect x="69.6" class="st0-x" width="7.4" height="7.4"/>
  <rect y="0" class="st1-x" width="15.9" height="8.2"/>
  <rect x="15.9" y="8.2" class="st1-x" width="8.2" height="8.2"/>
  <rect x="24.1" y="0" class="st2-x" width="8.7" height="23"/>
  <rect x="41" y="0" class="st2-x" width="28.6" height="7.4"/>
  </svg>
</div> 