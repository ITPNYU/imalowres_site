<div class="row">
  <div class="frontpage__notificationbox">
    <div class="frontpage__notificationtext">
      <p>We have 2 online information sessions scheduled for this Fall:<br/><br/>
      Monday, October 12, 2021 at 9pm ET. Here is the video recording.<br/>
      Wednesday, Sept 23, 2021s at 11am ET. Here is the video recording from our first session.
      </p>
    </div>

    <div class="frontpage__notificationbutton">
      <a href="./apply">
        <div class="frontpage__cta">Contact us</div>
      </a>
    </div>

  </div>
</div>