<div class="divider">
        <svg version="1.1" id="Laag_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
          viewBox="0 0 74.8 29" style="enable-background:new 0 0 74.8 29;" xml:space="preserve">
        <style type="text/css">
          .st0-x{fill:#FBFAE2;}
          .st1-x{fill:#1AA799;}
          .st2-x{fill:#E83F41;}
          .st3-x{fill:#F3B545;}
        </style>
        <rect x="63.1" class="st0-x" width="11.7" height="6"/>
        <rect x="57.1" class="st0-x" width="6" height="29"/>
        <rect class="st1-x" width="12" height="6"/>
        <rect y="22.9" class="st1-x" width="18.1" height="6"/>
        <rect x="6" y="6" class="st2-x" width="6" height="17"/>
        <rect x="18.1" class="st3-x" width="9.3" height="22.9"/>
        <rect x="33.4" class="st2-x" width="9.5" height="22.9"/>
        <rect x="27.4" y="22.9" class="st1-x" width="6" height="6"/>
        <rect x="43" y="22.9" class="st3-x" width="14.1" height="6"/>
        <rect x="49" class="st1-x" width="8.1" height="22.9"/>
        </svg>

      </div> 